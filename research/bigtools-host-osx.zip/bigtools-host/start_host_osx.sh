#!/bin/bash
python /Users/tatleung/Documents/bigtools/bigtools-host/bigtools_host.py $*
# cd /Users/tatleung/Documents/bigtools/bigtools-host
# code-insiders bogus.bml
