#!/bin/bash
#python CPQ_TOOL_HOST/bigtools_host.py $*
cd CPQ_TOOL_HOST
code-insiders bogus.bml
